[Web Sistemi i Tehnologije]

Skripta start_console.bat pokrece konzolu u novom virtual enviromentu za trenutni projekat
Skripta start_flask_server.bat pokrece main.py skriptu unutar src foldera

Za sve dodatne informacije: mveniger@raf.rs