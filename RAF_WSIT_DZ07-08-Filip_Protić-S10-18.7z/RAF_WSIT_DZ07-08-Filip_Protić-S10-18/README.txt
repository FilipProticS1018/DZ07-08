UPUTSTVO ZA KORISCENJE

Skripta generate.py generise projekat za Web Sisteme i Tehnologije
Kada se skripta pokrene pita za naziv projekta. 

UPOZORENJE: Naziv projekta ne sme sadrzati razmake, 
tako da ako zelite da se projekat zove "Projekat 1" morate staviti "Projekat_1"

Komanda za pokretanje:
	python generate.py
	
Dodatne informacije i pitanja: mveniger@raf.rs
	
